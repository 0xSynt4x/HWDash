use std::collections::HashMap;
use winreg::enums::*;
use winreg::RegKey;

#[tauri::command]
fn get_hardware_data() -> Result<HashMap<String, String>, String> {
    let hkcu = RegKey::predef(HKEY_CURRENT_USER);
    let path = r#"Software\FinalWire\AIDA64\SensorValues"#;

    // 打开注册表，如果失败返回错误信息给前端
    let key = hkcu.open_subkey(path).map_err(|e| e.to_string())?;
    let mut data = HashMap::new();

    // 遍历读取所有传感器数据
    for value in key.enum_values().filter_map(Result::ok) {
        let name = value.0;
        if let Ok(val_str) = key.get_value::<String, _>(&name) {
            data.insert(name, val_str);
        }
    }
    Ok(data)
}

#[cfg_attr(mobile, tauri::mobile_entry_point)]
pub fn run() {
    tauri::Builder::default()
        .plugin(tauri_plugin_opener::init())
        .invoke_handler(tauri::generate_handler![get_hardware_data]) // 注册命令
        .run(tauri::generate_context!())
        .expect("error while running tauri application");
}
